// Package session defines the Session and Notification types;
// It provides implementation for creating and deleting of server side session, client side cookie and use of notification inside session to pass messages between http request.
package session
