package web

// Server settings
const serverHost = "localhost"
const serverPort = "5221"
