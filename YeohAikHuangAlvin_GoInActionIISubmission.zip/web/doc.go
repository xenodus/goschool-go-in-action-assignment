// Package web defines route constants and provides the implementation for http handlers and server.
package web
