// Package clinic defines the Doctor, Patient, Appointment and Payment types, which implements their individual CRUD, search and helper methods.
package clinic
